"""Original AgriSight inference modules."""
